// Dummy Variable class
#ifndef VARIABLE_H
#define VARIABLE_H

class Variable
{
};

#endif
