// The JHU-MIT Proxy Re-encryption Library (PRL)
//
// proxylib.h: Main include file for implementation of pairing-based
// proxy re-encryption scheme.
//
// ================================================================
// 	
// Copyright (c) 2007, Matthew Green, Giuseppe Ateniese, Kevin Fu,
// Susan Hohenberger.  All rights reserved.
//
// Redistribution and use in source and binary forms, with or
// without modification, are permitted provided that the following
// conditions are met:												
//
// Redistributions of source code must retain the above copyright 
// notice, this list of conditions and the following disclaimer.  
// Redistributions in binary form must reproduce the above copyright
// notice, this list of conditions and the following disclaimer in 
// the documentation and/or other materials provided with the 
// distribution.
//
// Neither the names of the Johns Hopkins University, the Massachusetts
// Institute of Technology nor the names of its contributors may be 
// used to endorse or promote products derived from this software 
// without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
// COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
// INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
// BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
// ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
// POSSIBILITY OF SUCH DAMAGE.

#ifndef __PROXYLIB_H__
#define __PROXYLIB_H__

#include "ecn.h"
#include "ebrick.h"
#include "zzn2.h"

//
// Macros
//

#define PRINT_DEBUG_STRING(x) printDebugString(x)
#define ASCII_SEPARATOR "#"

//
// Constants
//

#define DEVRANDOM "/dev/urandom" // Not ideal, but faster than /dev/random

//
// Data structures and Classes
//

// Public parameters (shared among all users in a system)
class CurveParams {
 public:
  int bits;
  Big p, q, qsquared;
  ECn P;  
  ZZn2 Z;
  ZZn2 Zprecomp;
  ZZn2 cube;

  virtual int getSerializedSize(SERIALIZE_MODE mode); 
  virtual int serialize(SERIALIZE_MODE mode,
			char *buffer, int maxBuffer);
  virtual BOOL deserialize(SERIALIZE_MODE mode,
			   char *buffer, int maxBuffer);
  virtual int maxPlaintextSize() {
    Big temp;
    this->Z.get(temp);
    return ::bits(temp);
  }

  BOOL operator==(CurveParams &second) {
    return ((this->bits == second.bits) && 
	    (this->p == second.p) &&
	    (this->q == second.q) &&
	    (this->qsquared == second.qsquared) &&
	    (this->P == second.P) &&
	    (this->Z == second.Z) &&
	    (this->cube == second.cube));
  }

};

// ProxyPK: Public Key class
//
// This is a top-level class; specific proxy re-encryption schemes
// implement subclasses of this structure.

class ProxyPK {
public:
  SCHEME_TYPE schemeType;

  virtual int getSerializedSize(SERIALIZE_MODE mode) { return 0; } 
  virtual int serialize(SERIALIZE_MODE mode,
			     char *buffer, int maxBuffer) {
    return 0;
  }
  virtual BOOL deserialize(SERIALIZE_MODE mode,
			 char *buffer, int maxBuffer) {
    return FALSE;
  }
};

// ProxySK: Secret Key class
//
// This is a top-level class; specific proxy re-encryption schemes
// implement subclasses of this structure.

class ProxySK {
 public:
  SCHEME_TYPE schemeType;

  virtual int getSerializedSize(SERIALIZE_MODE mode) { return 0; } 
  virtual int serialize(SERIALIZE_MODE mode,
			char *buffer, int maxBuffer) {
    return 0;
  }
  virtual BOOL deserialize(SERIALIZE_MODE mode,
			 char *buffer, int maxBuffer) {
    return FALSE;
  }
};

// ProxyCiphertext: Ciphertext class
//
// This is a top-level class; specific re-encryption schemes
// implement subclasses of this structure.

class ProxyCiphertext {
 public:
  CIPHERTEXT_TYPE type;
  SCHEME_TYPE schemeType;

  virtual int getSerializedSize(SERIALIZE_MODE mode) { return 0; } 
  virtual int serialize(SERIALIZE_MODE mode,
			char *buffer, int maxBuffer) {
    return 0;
  }
  virtual BOOL deserialize(SERIALIZE_MODE mode,
			   char *buffer, int maxBuffer) {
    return FALSE;
  }
};

// Main C++ interface

BOOL initLibrary(BOOL selfseed = TRUE, char *seedbuf = NULL,
		 int bufSize = 0);

// Utility Routines

BOOL ReadParamsFile(char *filename, CurveParams &params);
BOOL ImportPublicKey(char *buffer, int bufferSize, ProxyPK &pubkey);
BOOL ImportSecretKey(char *buffer, int bufferSize, ProxySK &secret);
BOOL fast_tate_pairing(ECn& P,ZZn2& Qx,ZZn& Qy,Big& q,ZZn2& res);
BOOL ecap(ECn& P,ECn& Q,Big& order,ZZn2& cube,ZZn2& res);
ECn map_to_point(char *ID);
void strip(char *name);

// Core Routines
BOOL proxy_level1_encrypt(CurveParams &params, Big &plaintext, ProxyPK &publicKey, ZZn2 &res1, ZZn2 &res2);
BOOL proxy_level2_encrypt(CurveParams &params, ZZn2 zPlaintext, ProxyPK &publicKey, ECn &res1, ZZn2 &res2);
BOOL proxy_delegate(CurveParams &params, ProxyPK &delegate, ProxySK &delegator, ECn &reskey);
BOOL proxy_reencrypt(CurveParams &params, ECn &c1, ECn &delegation, ZZn2 &res1);
BOOL proxy_decrypt_level1(CurveParams &params, ZZn2 &c1, ZZn2 &c2, ProxySK &secretKey, Big &plaintext);
BOOL proxy_decrypt_level2(CurveParams &params, ECn &c1, ZZn2 &c2, ProxySK &secretKey, Big &plaintext);
BOOL proxy_decrypt_reencrypted(CurveParams &params, ZZn2 &c1, ZZn2 &c2, ProxySK &secretKey, Big &plaintext);

// Utility routines
BOOL encodePlaintextAsBig(CurveParams &params,
		     char *message, int messageLen, Big &msg);
BOOL decodePlaintextFromBig(CurveParams &params,
			  char *message, int maxMessage, 
			  int *messageLen, Big &msg);

/* Given a char array of bytes and its length, convert to a Big */
ECn charToECn (char *c, int *totLen);
ZZn2 charToZZn2 (char *c, int *totLen);

Big charToBig (char *c, int *totLen);
int BigTochar (Big &x, char *c, int s);

/* Given a big, encode as a byte string in the char, assuming its
   size is less than s
   Return length of bytes written to c, or -1 if error
*/
int ECnTochar (ECn &e, char *c, int s);
int ZZn2Tochar (ZZn2 &z, char *c, int s);

void bufrand(char* seedbuf, int seedsize);
BOOL entropyCollect(char *entropyBuf, int entropyBytes);

// Debug output routine
void printDebugString(string debugString);

//
// Set parameter sizes. For example change PBITS to 1024
//

#define PBITS 512
#define QBITS 160

#define HASH_LEN 20

#define SIMPLE
#define PROJECTIVE

// use static temp variables in crypto routines-- faster, but not
// thread safe
#define SAFESTATIC static
  
//
// Benchmarking
//

//#define BENCHMARKING 1

#define NUMBENCHMARKS 7
#define LEVELONEENCTIMING 0
#define LEVELTWOENCTIMING 1
#define DELEGATETIMING 2
#define REENCTIMING 3
#define LEVELONEDECTIMING 4
#define LEVELTWODECTIMING 5
#define REENCDECTIMING 6

#define LEVELONEENCDESC "Level-1 Encryption"
#define LEVELTWOENCDESC "Level-2 Encryption"
#define DELEGATEDESC "Proxy Delegation"
#define REENCDESC "Proxy Re-encryption"
#define LEVELONEDECDESC "Level-1 Decryption"
#define LEVELTWODECDESC "Level-2 Decryption"
#define REENCDECDESC "Re-encrypted Decryption"

#endif // __PROXYLIB_H__
